package com.example.mainlogin

object db {
    val posts = mutableListOf<Post>()

    init {
        posts.add(Post("Alden", "Enjoying the sunny day!", R.drawable.alden))
        posts.add(Post("Bob", "Just had coffee ☕", R.drawable.memes))
        posts.add(Post("Malupiton", "Araaaay Ko!", R.drawable.maxresdefault))

    }

    fun addPost(post: Post) {
        posts.add(post)
    }

    fun getAllPosts(): List<Post> = posts
}