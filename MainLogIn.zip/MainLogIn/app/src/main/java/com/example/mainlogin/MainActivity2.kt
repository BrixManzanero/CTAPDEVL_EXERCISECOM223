package com.example.mainlogin

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

        }
        val username = intent.getStringExtra("username_key")
        val bottomNav : BottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_navigation)

        val firstFragment = HomeFragment().apply {
            arguments = Bundle().apply {
                putString("username_key", username)
            }
        }
        val secondFragment = SearchFragment()

        val thirdFragment = ProfileFragment().apply {
            arguments = Bundle().apply {
                putString("username_key", username)
            }
        }

        setFragment(firstFragment)
        bottomNav.setOnItemSelectedListener {
            when(it.itemId){
                R.id.nav_home-> setFragment(firstFragment)
                R.id.nav_search-> setFragment(secondFragment)
                R.id.nav_profile-> setFragment(thirdFragment)
            }
            true
        }

    }

    private fun setFragment(fragment: Fragment) =
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.frameLayout, fragment)
            commit()
        }


}
