package com.example.mainlogin

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ProfileActivity : AppCompatActivity() {


    private val IMAGE_PICK_CODE = 1000
    private lateinit var imageView: ImageView
    private lateinit var profileImageView: ImageView


    private lateinit var selectImageButton: ImageView
    private lateinit var profileSelectImageButton: Button

    private var targetImageView: ImageView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_profile)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets





        }

        imageView = findViewById(R.id.imageView5)
        selectImageButton = findViewById(R.id.imageView10)
        profileImageView = findViewById(R.id.imageView2)
        profileSelectImageButton = findViewById(R.id.button2)
        selectImageButton.setOnClickListener {
            pickImageFromGallery()
        }



        selectImageButton.setOnClickListener {
            targetImageView = imageView
            pickImageFromGallery()
        }

        profileSelectImageButton.setOnClickListener {
            targetImageView = profileImageView
            pickImageFromGallery()
        }
    }
    private fun pickImageFromGallery() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "image/*"
        startActivityForResult(Intent.createChooser(intent, "Select Image"), IMAGE_PICK_CODE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == IMAGE_PICK_CODE && resultCode == Activity.RESULT_OK) {
            val imageUri: Uri? = data?.data
            targetImageView?.setImageURI(imageUri)
        }
    }
}