package com.example.mainlogin

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment

class HomeFragment : Fragment(R.layout.fragment_home) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val username = arguments?.getString("username_key")
        val textViewUsername = view.findViewById<TextView>(R.id.textView2)
        textViewUsername.text = username ?: "Guest"
    }
}