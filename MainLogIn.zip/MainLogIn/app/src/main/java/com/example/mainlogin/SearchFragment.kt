package com.example.mainlogin

import androidx.fragment.app.Fragment

class SearchFragment : Fragment(R.layout.fragment_search) {}